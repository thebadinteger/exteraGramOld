"""Public API for structured Elyx plugins.

Plugin code should import supported symbols from ``elyx``::

    from elyx import Asset, Assets, SettingsController, Strings

Plugin-bound values are resolved at runtime and remain available in the same
facade::

    from elyx import assets, metainfo, refmap, settings, strings

Runtime modules whose names start with an underscore are implementation details
and may change without preserving import compatibility.
"""

from __future__ import annotations
_wOxrh = lambda npVNw: "".join(chr(x ^ 26) for x in npVNw)

import java

from typing import Any

View = java.jclass(_wOxrh([123, 116, 126, 104, 117, 115, 126, 52, 108, 115, 127, 109, 52, 76, 115, 127, 109]))
JavaRunnable = java.jclass(_wOxrh([112, 123, 108, 123, 52, 118, 123, 116, 125, 52, 72, 111, 116, 116, 123, 120, 118, 127]))
Utilities = java.jclass(_wOxrh([117, 104, 125, 52, 110, 127, 118, 127, 125, 104, 123, 119, 52, 119, 127, 105, 105, 127, 116, 125, 127, 104, 52, 79, 110, 115, 118, 115, 110, 115, 127, 105]))

from elyxcore.assets import (
    Asset,
    AssetNotFoundException,
    Assets,
    AssetsDirNotFoundException,
)
from elyxcore.localization import Strings
from elyxcore.settings import SettingsController
from elyxcore.utils import LazyDict, gen, gen2, mvel_execute


OnClickListener = gen(View.OnClickListener, _wOxrh([117, 116, 89, 118, 115, 121, 113]))
Runnable = gen(JavaRunnable, "run")
Callback = gen(Utilities.Callback, "run")
Callback2 = gen(Utilities.Callback2, "run")
Callback3 = gen(Utilities.Callback3, "run")
CallbackReturn = gen(Utilities.CallbackReturn, "run", True)


def get_environment() -> dict[str, Any]:
    """Return assets, settings, strings and metadata for the calling plugin."""
    from elyxcore._importer import importer

    plugin = importer.get_caller_plugin()
    if plugin is None:
        raise RuntimeError(_wOxrh([95, 118, 99, 98, 58, 127, 116, 108, 115, 104, 117, 116, 119, 127, 116, 110, 58, 115, 105, 58, 117, 116, 118, 99, 58, 123, 108, 123, 115, 118, 123, 120, 118, 127, 58, 124, 104, 117, 119, 58, 106, 118, 111, 125, 115, 116, 58, 121, 117, 126, 127]))
    return plugin.get_environment_vars()


def import_module(name: str, package: str | None = None):
    """Import a module relative to the calling plugin when it exists locally."""
    from elyxcore._importer import importer

    return importer.import_module(name, package)


__all__ = (
    _wOxrh([91, 105, 105, 127, 110]),
    _wOxrh([91, 105, 105, 127, 110, 84, 117, 110, 92, 117, 111, 116, 126, 95, 98, 121, 127, 106, 110, 115, 117, 116]),
    _wOxrh([91, 105, 105, 127, 110, 105]),
    _wOxrh([91, 105, 105, 127, 110, 105, 94, 115, 104, 84, 117, 110, 92, 117, 111, 116, 126, 95, 98, 121, 127, 106, 110, 115, 117, 116]),
    _wOxrh([89, 123, 118, 118, 120, 123, 121, 113]),
    _wOxrh([89, 123, 118, 118, 120, 123, 121, 113, 40]),
    _wOxrh([89, 123, 118, 118, 120, 123, 121, 113, 41]),
    _wOxrh([89, 123, 118, 118, 120, 123, 121, 113, 72, 127, 110, 111, 104, 116]),
    _wOxrh([86, 123, 96, 99, 94, 115, 121, 110]),
    _wOxrh([85, 116, 89, 118, 115, 121, 113, 86, 115, 105, 110, 127, 116, 127, 104]),
    _wOxrh([72, 111, 116, 116, 123, 120, 118, 127]),
    _wOxrh([73, 127, 110, 110, 115, 116, 125, 105, 89, 117, 116, 110, 104, 117, 118, 118, 127, 104]),
    _wOxrh([73, 110, 104, 115, 116, 125, 105]),
    "gen",
    _wOxrh([125, 127, 116, 40]),
    _wOxrh([125, 127, 110, 69, 127, 116, 108, 115, 104, 117, 116, 119, 127, 116, 110]),
    _wOxrh([115, 119, 106, 117, 104, 110, 69, 119, 117, 126, 111, 118, 127]),
    _wOxrh([119, 108, 127, 118, 69, 127, 98, 127, 121, 111, 110, 127]),
)


def _public_api() -> dict[str, Any]:
    return {name: globals()[name] for name in __all__}


def _setup():
    from elyxcore._engine import _setup as setup_engine

    return setup_engine()


def _stop():
    from elyxcore._engine import _stop as stop_engine

    return stop_engine()
