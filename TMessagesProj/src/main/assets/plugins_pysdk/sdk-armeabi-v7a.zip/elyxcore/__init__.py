"""Public API for structured Elyx plugins.

Plugin code should import supported symbols from ``elyx``::

    from elyx import Asset, Assets, SettingsController, Strings

Plugin-bound values are resolved at runtime and remain available in the same
facade::

    from elyx import assets, metainfo, refmap, settings, strings

Runtime modules whose names start with an underscore are implementation details
and may change without preserving import compatibility.
"""

from __future__ import annotations
_UFal = lambda SivD: "".join(chr(x ^ 85) for x in SivD)

import java

from typing import Any

View = java.jclass(_UFal([52, 59, 49, 39, 58, 60, 49, 123, 35, 60, 48, 34, 123, 3, 60, 48, 34]))
JavaRunnable = java.jclass(_UFal([63, 52, 35, 52, 123, 57, 52, 59, 50, 123, 7, 32, 59, 59, 52, 55, 57, 48]))
Utilities = java.jclass(_UFal([58, 39, 50, 123, 33, 48, 57, 48, 50, 39, 52, 56, 123, 56, 48, 38, 38, 48, 59, 50, 48, 39, 123, 0, 33, 60, 57, 60, 33, 60, 48, 38]))

from elyxcore.assets import (
    Asset,
    AssetNotFoundException,
    Assets,
    AssetsDirNotFoundException,
)
from elyxcore.localization import Strings
from elyxcore.settings import SettingsController
from elyxcore.utils import LazyDict, gen, gen2, mvel_execute


OnClickListener = gen(View.OnClickListener, _UFal([58, 59, 22, 57, 60, 54, 62]))
Runnable = gen(JavaRunnable, "run")
Callback = gen(Utilities.Callback, "run")
Callback2 = gen(Utilities.Callback2, "run")
Callback3 = gen(Utilities.Callback3, "run")
CallbackReturn = gen(Utilities.CallbackReturn, "run", True)


def get_environment() -> dict[str, Any]:
    """Return assets, settings, strings and metadata for the calling plugin."""
    from elyxcore._importer import importer

    plugin = importer.get_caller_plugin()
    if plugin is None:
        raise RuntimeError(_UFal([16, 57, 44, 45, 117, 48, 59, 35, 60, 39, 58, 59, 56, 48, 59, 33, 117, 60, 38, 117, 58, 59, 57, 44, 117, 52, 35, 52, 60, 57, 52, 55, 57, 48, 117, 51, 39, 58, 56, 117, 37, 57, 32, 50, 60, 59, 117, 54, 58, 49, 48]))
    return plugin.get_environment_vars()


def import_module(name: str, package: str | None = None):
    """Import a module relative to the calling plugin when it exists locally."""
    from elyxcore._importer import importer

    return importer.import_module(name, package)


__all__ = (
    _UFal([20, 38, 38, 48, 33]),
    _UFal([20, 38, 38, 48, 33, 27, 58, 33, 19, 58, 32, 59, 49, 16, 45, 54, 48, 37, 33, 60, 58, 59]),
    _UFal([20, 38, 38, 48, 33, 38]),
    _UFal([20, 38, 38, 48, 33, 38, 17, 60, 39, 27, 58, 33, 19, 58, 32, 59, 49, 16, 45, 54, 48, 37, 33, 60, 58, 59]),
    _UFal([22, 52, 57, 57, 55, 52, 54, 62]),
    _UFal([22, 52, 57, 57, 55, 52, 54, 62, 103]),
    _UFal([22, 52, 57, 57, 55, 52, 54, 62, 102]),
    _UFal([22, 52, 57, 57, 55, 52, 54, 62, 7, 48, 33, 32, 39, 59]),
    _UFal([25, 52, 47, 44, 17, 60, 54, 33]),
    _UFal([26, 59, 22, 57, 60, 54, 62, 25, 60, 38, 33, 48, 59, 48, 39]),
    _UFal([7, 32, 59, 59, 52, 55, 57, 48]),
    _UFal([6, 48, 33, 33, 60, 59, 50, 38, 22, 58, 59, 33, 39, 58, 57, 57, 48, 39]),
    _UFal([6, 33, 39, 60, 59, 50, 38]),
    "gen",
    _UFal([50, 48, 59, 103]),
    _UFal([50, 48, 33, 10, 48, 59, 35, 60, 39, 58, 59, 56, 48, 59, 33]),
    _UFal([60, 56, 37, 58, 39, 33, 10, 56, 58, 49, 32, 57, 48]),
    _UFal([56, 35, 48, 57, 10, 48, 45, 48, 54, 32, 33, 48]),
)


def _public_api() -> dict[str, Any]:
    return {name: globals()[name] for name in __all__}


def _setup():
    from elyxcore._engine import _setup as setup_engine

    return setup_engine()


def _stop():
    from elyxcore._engine import _stop as stop_engine

    return stop_engine()
